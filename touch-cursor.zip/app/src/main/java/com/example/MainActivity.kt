package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CursorPreferencesRepository
import com.example.service.CursorAccessibilityService
import com.example.ui.CursorViewModel
import com.example.ui.TouchCursorScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: CursorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CursorPreferencesRepository.init(applicationContext)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val settings by viewModel.cursorSettings.collectAsStateWithLifecycle()
                val permissionState by viewModel.permissionState.collectAsStateWithLifecycle()
                val lifecycleOwner = LocalLifecycleOwner.current

                // Refresh overlay and AccessibilityService permission status whenever returning from Settings
                DisposableEffect(lifecycleOwner) {
                    val observer = LifecycleEventObserver { _, event ->
                        if (event == Lifecycle.Event.ON_RESUME) {
                            viewModel.refreshPermissions(this@MainActivity)
                        }
                    }
                    lifecycleOwner.lifecycle.addObserver(observer)
                    onDispose {
                        lifecycleOwner.lifecycle.removeObserver(observer)
                    }
                }

                // Launcher for 'Select Click Sound' button (opens system audio file picker for .mp3, .wav, etc.)
                val audioPickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocument()
                ) { uri: Uri? ->
                    if (uri != null) {
                        viewModel.onCustomSoundUriSelected(this@MainActivity, uri)
                    }
                }

                // Launcher for SYSTEM_ALERT_WINDOW (Draw over other apps) permission settings screen
                val overlayPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) {
                    viewModel.refreshPermissions(this@MainActivity)
                }

                TouchCursorScreen(
                    settings = settings,
                    permissionState = permissionState,
                    onSelectSoundClick = {
                        audioPickerLauncher.launch(arrayOf("audio/*"))
                    },
                    onToggleCursorService = { enabled ->
                        viewModel.onToggleCursorService(enabled, this@MainActivity)
                        if (enabled) {
                            // Prompt for missing permissions if not yet granted
                            if (!Settings.canDrawOverlays(this@MainActivity)) {
                                requestOverlayPermission { intent ->
                                    overlayPermissionLauncher.launch(intent)
                                }
                            } else if (!CursorAccessibilityService.isAccessibilityServiceEnabled(this@MainActivity)) {
                                openAccessibilitySettings()
                            }
                        }
                    },
                    onRequestOverlayPermission = {
                        requestOverlayPermission { intent ->
                            overlayPermissionLauncher.launch(intent)
                        }
                    },
                    onRequestAccessibilityPermission = {
                        openAccessibilitySettings()
                    },
                    onSelectPreset = { preset ->
                        viewModel.onSelectBuiltInPreset(preset, this@MainActivity)
                    },
                    onSelectCursorStyle = { style ->
                        viewModel.onSelectCursorStyle(style, this@MainActivity)
                    },
                    onUpdateCursorSizeDp = { sizeDp ->
                        viewModel.onUpdateCursorSizeDp(sizeDp, this@MainActivity)
                    },
                    onUpdateSlideDurationMs = { durationMs ->
                        viewModel.onUpdateSlideDurationMs(durationMs)
                    },
                    onUpdateSoundVolume = { volume ->
                        viewModel.onUpdateSoundVolume(volume)
                    },
                    onTestSoundClick = {
                        viewModel.testClickSound(this@MainActivity)
                    },
                    onPlaygroundTap = { rawX, rawY ->
                        CursorAccessibilityService.notifyDirectTouchCoordinate(
                            context = this@MainActivity,
                            rawX = rawX,
                            rawY = rawY
                        )
                    }
                )
            }
        }
    }

    /**
     * Intercepts touch downs inside the activity when the Cursor Service toggle is enabled
     * so the floating cursor slides to exact (rawX, rawY) touch coordinates and plays the
     * selected click sound immediately.
     */
    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (ev?.actionMasked == MotionEvent.ACTION_DOWN) {
            if (CursorPreferencesRepository.state.value.isServiceToggleEnabled) {
                CursorAccessibilityService.notifyDirectTouchCoordinate(
                    context = applicationContext,
                    rawX = ev.rawX,
                    rawY = ev.rawY
                )
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun requestOverlayPermission(launchIntent: (Intent) -> Unit) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        runCatching { launchIntent(intent) }
    }

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { startActivity(intent) }
    }
}
