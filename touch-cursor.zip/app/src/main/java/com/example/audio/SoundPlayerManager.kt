package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import com.example.data.ClickSoundPreset
import com.example.data.CursorPreferencesRepository
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Manages playback of the user-selected click sound effect using [MediaPlayer].
 *
 * Uses a synchronized round-robin pool of prepared [MediaPlayer] instances so rapid
 * consecutive clicks overlap cleanly or rewind instantaneously without throwing
 * [IllegalStateException] or exhausting hardware audio decoders.
 */
object SoundPlayerManager {
    private const val TAG = "SoundPlayerManager"
    private const val POOL_SIZE = 4

    private val lock = Any()
    private val playerPool = mutableListOf<MediaPlayer>()
    private var activeSourceKey: String? = null
    private var poolCursorIndex = 0

    private val audioAttributes: AudioAttributes by lazy {
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
    }

    /**
     * Plays the currently configured click sound (either the user's selected audio file URI
     * from MainActivity or the selected built-in WAV click preset) using [MediaPlayer].
     * Safe for rapid consecutive clicks.
     */
    fun playClickSound(context: Context) {
        val appContext = context.applicationContext
        CursorPreferencesRepository.init(appContext)
        val currentState = CursorPreferencesRepository.state.value
        val volume = currentState.soundVolume.coerceIn(0f, 1f)
        if (volume <= 0.01f) return

        val targetUri: Uri = resolveTargetSoundUri(
            context = appContext,
            customUriString = currentState.selectedSoundUriString,
            preset = currentState.selectedPreset
        )

        playUriSafely(appContext, targetUri, volume)
    }

    /**
     * Plays a specific [Uri] with [MediaPlayer], handling rapid consecutive clicks safely.
     */
    fun playUriSafely(context: Context, uri: Uri, volume: Float = 0.9f) {
        val appContext = context.applicationContext
        val sourceKey = uri.toString()

        synchronized(lock) {
            if (activeSourceKey != sourceKey || playerPool.isEmpty()) {
                rebuildPlayerPoolLocked(appContext, uri, sourceKey)
            }

            if (playerPool.isEmpty()) {
                // If the custom URI failed to load (e.g. revoked permission), fall back to built-in click WAV
                val fallbackUri = getOrCreateSynthesizedWavUri(
                    appContext,
                    ClickSoundPreset.MECHANICAL_CLICK
                )
                if (sourceKey != fallbackUri.toString()) {
                    rebuildPlayerPoolLocked(appContext, fallbackUri, fallbackUri.toString())
                }
            }

            if (playerPool.isEmpty()) return

            val player = playerPool[poolCursorIndex % playerPool.size]
            poolCursorIndex = (poolCursorIndex + 1) % playerPool.size

            try {
                player.setVolume(volume, volume)
                if (player.isPlaying) {
                    player.seekTo(0)
                } else {
                    player.seekTo(0)
                    player.start()
                }
            } catch (e: IllegalStateException) {
                Log.w(TAG, "Recovering MediaPlayer instance on rapid click: ${e.message}")
                recoverSinglePlayerLocked(appContext, player, uri, volume)
            } catch (e: Exception) {
                Log.e(TAG, "Unexpected error playing click sound: ${e.message}")
            }
        }
    }

    /**
     * Pre-warms the [MediaPlayer] pool when the user selects a new sound in MainActivity.
     */
    fun preloadSelectedSound(context: Context) {
        val appContext = context.applicationContext
        CursorPreferencesRepository.init(appContext)
        val state = CursorPreferencesRepository.state.value
        val targetUri = resolveTargetSoundUri(
            context = appContext,
            customUriString = state.selectedSoundUriString,
            preset = state.selectedPreset
        )
        synchronized(lock) {
            rebuildPlayerPoolLocked(appContext, targetUri, targetUri.toString())
        }
    }

    /**
     * Releases all pooled [MediaPlayer] instances cleanly.
     */
    fun releaseAll() {
        synchronized(lock) {
            playerPool.forEach { player ->
                runCatching {
                    if (player.isPlaying) {
                        player.stop()
                    }
                }
                runCatching { player.reset() }
                runCatching { player.release() }
            }
            playerPool.clear()
            activeSourceKey = null
            poolCursorIndex = 0
        }
    }

    private fun rebuildPlayerPoolLocked(context: Context, uri: Uri, sourceKey: String) {
        releaseAll()
        for (i in 0 until POOL_SIZE) {
            val mp = createPreparedMediaPlayer(context, uri)
            if (mp != null) {
                playerPool.add(mp)
            } else if (i == 0) {
                // First instance failed; abort building pool for this invalid URI
                break
            }
        }
        if (playerPool.isNotEmpty()) {
            activeSourceKey = sourceKey
            poolCursorIndex = 0
        }
    }

    private fun createPreparedMediaPlayer(context: Context, uri: Uri): MediaPlayer? {
        return try {
            MediaPlayer().apply {
                setAudioAttributes(audioAttributes)
                setDataSource(context, uri)
                setOnErrorListener { mp, what, extra ->
                    Log.w(TAG, "MediaPlayer error ($what, $extra), resetting instance")
                    runCatching {
                        mp.reset()
                        mp.setAudioAttributes(audioAttributes)
                        mp.setDataSource(context, uri)
                        mp.prepare()
                    }
                    true
                }
                prepare()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to prepare MediaPlayer for $uri: ${e.message}")
            null
        }
    }

    private fun recoverSinglePlayerLocked(
        context: Context,
        player: MediaPlayer,
        uri: Uri,
        volume: Float
    ) {
        runCatching {
            player.reset()
            player.setAudioAttributes(audioAttributes)
            player.setDataSource(context, uri)
            player.prepare()
            player.setVolume(volume, volume)
            player.start()
        }
    }

    private fun resolveTargetSoundUri(
        context: Context,
        customUriString: String?,
        preset: ClickSoundPreset
    ): Uri {
        if (preset == ClickSoundPreset.CUSTOM_FILE && !customUriString.isNullOrBlank()) {
            return Uri.parse(customUriString)
        }
        return getOrCreateSynthesizedWavUri(context, preset)
    }

    /**
     * Generates a crisp, low-latency 16-bit PCM WAV file in cacheDir so [MediaPlayer]
     * always has a valid audio URI even before the user picks an external .mp3 file.
     */
    private fun getOrCreateSynthesizedWavUri(context: Context, preset: ClickSoundPreset): Uri {
        val fileName = "cursor_click_${preset.name.lowercase()}.wav"
        val file = File(context.cacheDir, fileName)
        if (!file.exists() || file.length() < 100L) {
            writeClickWavFile(file, preset.frequencyHz, preset.decayMs)
        }
        return Uri.fromFile(file)
    }

    private fun writeClickWavFile(outputFile: File, freqHz: Double, durationMs: Int) {
        val sampleRate = 44100
        val numSamples = (sampleRate * durationMs) / 1000
        val pcmData = ByteArray(numSamples * 2)
        val pcmBuffer = ByteBuffer.wrap(pcmData).order(ByteOrder.LITTLE_ENDIAN)

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            // Exponential envelope with crisp initial transient click + harmonic overtone
            val envelope = exp(-t * (1000.0 / (durationMs * 0.28)))
            val fundamental = sin(2.0 * PI * freqHz * t)
            val harmonic = 0.45 * sin(2.0 * PI * (freqHz * 2.4) * t)
            val transientBurst = if (i < sampleRate / 400) 0.55 else 0.0
            val sampleValue = ((fundamental + harmonic + transientBurst) * envelope * 0.55)
                .coerceIn(-1.0, 1.0)
            val shortSample = (sampleValue * Short.MAX_VALUE).toInt().toShort()
            pcmBuffer.putShort(shortSample)
        }

        val totalDataLen = pcmData.size + 36
        val byteRate = sampleRate * 2 // 16-bit mono

        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(totalDataLen)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16) // PCM chunk size
            putShort(1) // AudioFormat = 1 (PCM)
            putShort(1) // NumChannels = 1 (Mono)
            putInt(sampleRate)
            putInt(byteRate)
            putShort(2) // BlockAlign
            putShort(16) // BitsPerSample
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(pcmData.size)
        }.array()

        runCatching {
            FileOutputStream(outputFile).use { fos ->
                fos.write(header)
                fos.write(pcmData)
                fos.flush()
            }
        }
    }
}
