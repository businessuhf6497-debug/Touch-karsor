package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import com.example.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class CursorStyle(val label: String, val drawableRes: Int) {
    CLASSIC_CYAN("Electric Cyan", R.drawable.ic_mouse_cursor),
    NEON_INDIGO("Neon Indigo", R.drawable.ic_mouse_cursor_neon),
    PRECISION_CROSSHAIR("Crosshair", R.drawable.ic_mouse_cursor_crosshair)
}

enum class ClickSoundPreset(val label: String, val frequencyHz: Double, val decayMs: Int) {
    MECHANICAL_CLICK("Mechanical Switch", 1450.0, 42),
    CYBER_PULSE("Cyber Pulse", 2100.0, 55),
    SOFT_POP("Soft Tactile Pop", 780.0, 38),
    CUSTOM_FILE("Custom Audio File", 1000.0, 45)
}

data class CursorSettingsState(
    val isServiceToggleEnabled: Boolean = false,
    val selectedSoundUriString: String? = null,
    val selectedSoundDisplayName: String = "Mechanical Switch (Default)",
    val selectedPreset: ClickSoundPreset = ClickSoundPreset.MECHANICAL_CLICK,
    val cursorStyle: CursorStyle = CursorStyle.CLASSIC_CYAN,
    val cursorSizeDp: Int = 38,
    val slideDurationMs: Long = 210L,
    val soundVolume: Float = 0.90f,
    val lastTouchX: Float = 240f,
    val lastTouchY: Float = 420f,
    val totalClicksIntercepted: Int = 0
)

object CursorPreferencesRepository {
    private const val PREFS_NAME = "touch_cursor_prefs"
    private const val KEY_SERVICE_ENABLED = "service_toggle_enabled"
    private const val KEY_SOUND_URI = "selected_sound_uri"
    private const val KEY_SOUND_NAME = "selected_sound_name"
    private const val KEY_SOUND_PRESET = "selected_sound_preset"
    private const val KEY_CURSOR_STYLE = "cursor_style"
    private const val KEY_CURSOR_SIZE_DP = "cursor_size_dp"
    private const val KEY_SLIDE_DURATION_MS = "slide_duration_ms"
    private const val KEY_SOUND_VOLUME = "sound_volume"
    private const val KEY_TOTAL_CLICKS = "total_clicks"

    private var prefs: SharedPreferences? = null

    private val _state = MutableStateFlow(CursorSettingsState())
    val state: StateFlow<CursorSettingsState> = _state.asStateFlow()

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val sharedPrefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = sharedPrefs

        val uriStr = sharedPrefs.getString(KEY_SOUND_URI, null)
        val presetName = sharedPrefs.getString(KEY_SOUND_PRESET, ClickSoundPreset.MECHANICAL_CLICK.name)
        val preset = runCatching { ClickSoundPreset.valueOf(presetName ?: "") }
            .getOrDefault(ClickSoundPreset.MECHANICAL_CLICK)

        val styleName = sharedPrefs.getString(KEY_CURSOR_STYLE, CursorStyle.CLASSIC_CYAN.name)
        val style = runCatching { CursorStyle.valueOf(styleName ?: "") }
            .getOrDefault(CursorStyle.CLASSIC_CYAN)

        val defaultDisplayName = if (preset == ClickSoundPreset.CUSTOM_FILE && !uriStr.isNullOrBlank()) {
            sharedPrefs.getString(KEY_SOUND_NAME, "Custom Audio (.mp3)") ?: "Custom Audio (.mp3)"
        } else {
            "${preset.label} (Built-in)"
        }

        _state.value = CursorSettingsState(
            isServiceToggleEnabled = sharedPrefs.getBoolean(KEY_SERVICE_ENABLED, false),
            selectedSoundUriString = uriStr,
            selectedSoundDisplayName = defaultDisplayName,
            selectedPreset = preset,
            cursorStyle = style,
            cursorSizeDp = sharedPrefs.getInt(KEY_CURSOR_SIZE_DP, 38).coerceIn(24, 68),
            slideDurationMs = sharedPrefs.getLong(KEY_SLIDE_DURATION_MS, 210L).coerceIn(50L, 650L),
            soundVolume = sharedPrefs.getFloat(KEY_SOUND_VOLUME, 0.90f).coerceIn(0f, 1f),
            totalClicksIntercepted = sharedPrefs.getInt(KEY_TOTAL_CLICKS, 0)
        )
    }

    fun setServiceToggleEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_SERVICE_ENABLED, enabled)?.apply()
        _state.update { it.copy(isServiceToggleEnabled = enabled) }
    }

    fun setCustomSoundUri(context: Context, uri: Uri) {
        val displayName = resolveFileName(context, uri)
        val uriString = uri.toString()
        prefs?.edit()
            ?.putString(KEY_SOUND_URI, uriString)
            ?.putString(KEY_SOUND_NAME, displayName)
            ?.putString(KEY_SOUND_PRESET, ClickSoundPreset.CUSTOM_FILE.name)
            ?.apply()

        _state.update {
            it.copy(
                selectedSoundUriString = uriString,
                selectedSoundDisplayName = displayName,
                selectedPreset = ClickSoundPreset.CUSTOM_FILE
            )
        }
    }

    fun setBuiltInPreset(preset: ClickSoundPreset) {
        if (preset == ClickSoundPreset.CUSTOM_FILE) return
        val displayName = "${preset.label} (Built-in)"
        prefs?.edit()
            ?.putString(KEY_SOUND_PRESET, preset.name)
            ?.putString(KEY_SOUND_NAME, displayName)
            ?.apply()

        _state.update {
            it.copy(
                selectedPreset = preset,
                selectedSoundDisplayName = displayName
            )
        }
    }

    fun setCursorStyle(style: CursorStyle) {
        prefs?.edit()?.putString(KEY_CURSOR_STYLE, style.name)?.apply()
        _state.update { it.copy(cursorStyle = style) }
    }

    fun setCursorSizeDp(sizeDp: Int) {
        val coerced = sizeDp.coerceIn(24, 68)
        prefs?.edit()?.putInt(KEY_CURSOR_SIZE_DP, coerced)?.apply()
        _state.update { it.copy(cursorSizeDp = coerced) }
    }

    fun setSlideDurationMs(durationMs: Long) {
        val coerced = durationMs.coerceIn(50L, 650L)
        prefs?.edit()?.putLong(KEY_SLIDE_DURATION_MS, coerced)?.apply()
        _state.update { it.copy(slideDurationMs = coerced) }
    }

    fun setSoundVolume(volume: Float) {
        val coerced = volume.coerceIn(0f, 1f)
        prefs?.edit()?.putFloat(KEY_SOUND_VOLUME, coerced)?.apply()
        _state.update { it.copy(soundVolume = coerced) }
    }

    fun recordTouchEvent(x: Float, y: Float) {
        val nextCount = _state.value.totalClicksIntercepted + 1
        prefs?.edit()?.putInt(KEY_TOTAL_CLICKS, nextCount)?.apply()
        _state.update {
            it.copy(
                lastTouchX = x,
                lastTouchY = y,
                totalClicksIntercepted = nextCount
            )
        }
    }

    private fun resolveFileName(context: Context, uri: Uri): String {
        runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0 && cursor.moveToFirst()) {
                    val name = cursor.getString(nameIndex)
                    if (!name.isNullOrBlank()) return name
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
            ?: "Custom Click Audio.mp3"
    }
}
