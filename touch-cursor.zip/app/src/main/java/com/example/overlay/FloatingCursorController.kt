package com.example.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.util.Property
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import com.example.audio.SoundPlayerManager
import com.example.data.CursorPreferencesRepository
import kotlin.math.roundToInt

/**
 * Manages the system-wide floating mouse cursor [ImageView] using [WindowManager]
 * with [WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY] and animates its position
 * smoothly using [ObjectAnimator].
 */
object FloatingCursorController {
    private const val TAG = "FloatingCursorCtrl"

    private val mainHandler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var cursorImageView: ImageView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var activeSlideAnimator: AnimatorSet? = null

    private var currentX: Float = 240f
    private var currentY: Float = 420f
    private var isOverlayAttached: Boolean = false

    /**
     * Custom [Property] allowing [ObjectAnimator] to smoothly animate the X coordinate
     * of the floating cursor [ImageView] inside [WindowManager].
     */
    private val CURSOR_WINDOW_X = object : Property<ImageView, Float>(Float::class.java, "cursorWindowX") {
        override fun get(view: ImageView): Float = currentX

        override fun set(view: ImageView, value: Float) {
            currentX = value
            val lp = layoutParams ?: return
            val wm = windowManager ?: return
            if (isOverlayAttached && view.isAttachedToWindow) {
                lp.x = value.roundToInt()
                runCatching { wm.updateViewLayout(view, lp) }
            }
        }
    }

    /**
     * Custom [Property] allowing [ObjectAnimator] to smoothly animate the Y coordinate
     * of the floating cursor [ImageView] inside [WindowManager].
     */
    private val CURSOR_WINDOW_Y = object : Property<ImageView, Float>(Float::class.java, "cursorWindowY") {
        override fun get(view: ImageView): Float = currentY

        override fun set(view: ImageView, value: Float) {
            currentY = value
            val lp = layoutParams ?: return
            val wm = windowManager ?: return
            if (isOverlayAttached && view.isAttachedToWindow) {
                lp.y = value.roundToInt()
                runCatching { wm.updateViewLayout(view, lp) }
            }
        }
    }

    fun isShowing(): Boolean = isOverlayAttached && cursorImageView != null

    /**
     * Displays the floating mouse cursor [ImageView] using [WindowManager] with
     * [WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY] if overlay permission is granted.
     */
    fun showCursorOverlay(context: Context): Boolean {
        val appContext = context.applicationContext
        CursorPreferencesRepository.init(appContext)

        if (!Settings.canDrawOverlays(appContext)) {
            Log.w(TAG, "Cannot show cursor overlay: SYSTEM_ALERT_WINDOW permission not granted")
            return false
        }

        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { showCursorOverlay(appContext) }
            return true
        }

        if (isOverlayAttached && cursorImageView != null) {
            refreshCursorAppearance(appContext)
            return true
        }

        val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val settings = CursorPreferencesRepository.state.value
        val sizePx = dpToPx(appContext, settings.cursorSizeDp)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = currentX.roundToInt()
            y = currentY.roundToInt()
        }

        val imageView = ImageView(appContext).apply {
            setImageResource(settings.cursorStyle.drawableRes)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Floating Mouse Cursor"
        }

        return try {
            wm.addView(imageView, params)
            cursorImageView = imageView
            layoutParams = params
            isOverlayAttached = true
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to add floating cursor overlay view: ${e.message}", e)
            cursorImageView = null
            layoutParams = null
            isOverlayAttached = false
            false
        }
    }

    /**
     * Removes the floating cursor [ImageView] from [WindowManager].
     */
    fun hideCursorOverlay() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { hideCursorOverlay() }
            return
        }

        activeSlideAnimator?.cancel()
        activeSlideAnimator = null

        val view = cursorImageView
        val wm = windowManager
        if (view != null && wm != null && isOverlayAttached) {
            runCatching { wm.removeView(view) }
        }
        cursorImageView = null
        layoutParams = null
        isOverlayAttached = false
    }

    /**
     * Updates the cursor drawable and size in real time when the user adjusts settings.
     */
    fun refreshCursorAppearance(context: Context) {
        mainHandler.post {
            val appContext = context.applicationContext
            val view = cursorImageView ?: return@post
            val lp = layoutParams ?: return@post
            val wm = windowManager ?: return@post
            if (!isOverlayAttached) return@post

            val settings = CursorPreferencesRepository.state.value
            val sizePx = dpToPx(appContext, settings.cursorSizeDp)
            view.setImageResource(settings.cursorStyle.drawableRes)
            lp.width = sizePx
            lp.height = sizePx
            runCatching { wm.updateViewLayout(view, lp) }
        }
    }

    /**
     * Smoothly slides the floating cursor [ImageView] to ([targetX], [targetY]) using
     * [ObjectAnimator], and plays the user's selected click sound effect via [MediaPlayer]
     * once the cursor arrives at the touch coordinates.
     */
    fun slideCursorToAndClick(
        context: Context,
        targetX: Float,
        targetY: Float,
        playClickSoundOnArrival: Boolean = true
    ) {
        val appContext = context.applicationContext
        CursorPreferencesRepository.init(appContext)
        CursorPreferencesRepository.recordTouchEvent(targetX, targetY)

        mainHandler.post {
            val settings = CursorPreferencesRepository.state.value

            // Ensure overlay is shown if overlay permission is granted and service toggle is active
            if (!isOverlayAttached && settings.isServiceToggleEnabled && Settings.canDrawOverlays(appContext)) {
                showCursorOverlay(appContext)
            }

            val view = cursorImageView
            if (view != null && isOverlayAttached) {
                activeSlideAnimator?.cancel()

                val animX = ObjectAnimator.ofFloat(view, CURSOR_WINDOW_X, currentX, targetX)
                val animY = ObjectAnimator.ofFloat(view, CURSOR_WINDOW_Y, currentY, targetY)

                val slideSet = AnimatorSet().apply {
                    playTogether(animX, animY)
                    duration = settings.slideDurationMs
                    interpolator = DecelerateInterpolator(1.6f)
                    addListener(object : AnimatorListenerAdapter() {
                        private var wasCancelled = false

                        override fun onAnimationCancel(animation: Animator) {
                            wasCancelled = true
                        }

                        override fun onAnimationEnd(animation: Animator) {
                            // Play subtle click press animation on the cursor ImageView
                            playClickTapPulse(view)
                            // Even on rapid consecutive taps where an animation is superseded,
                            // we ensure responsive audio feedback without dropping clicks
                            if (playClickSoundOnArrival && !wasCancelled) {
                                SoundPlayerManager.playClickSound(appContext)
                            }
                        }
                    })
                }

                // If the previous animation was cancelled mid-slide due to rapid tapping,
                // play the click sound immediately so rapid clicks always produce audio feedback
                if (activeSlideAnimator?.isRunning == true && playClickSoundOnArrival) {
                    SoundPlayerManager.playClickSound(appContext)
                }

                activeSlideAnimator = slideSet
                slideSet.start()
            } else {
                // Even if the system overlay isn't attached yet (e.g., testing inside the app
                // before granting SYSTEM_ALERT_WINDOW), update coordinates and trigger sound after slide duration
                currentX = targetX
                currentY = targetY
                if (playClickSoundOnArrival) {
                    mainHandler.postDelayed(
                        { SoundPlayerManager.playClickSound(appContext) },
                        settings.slideDurationMs
                    )
                }
            }
        }
    }

    private fun playClickTapPulse(view: ImageView) {
        val scaleX = ObjectAnimator.ofFloat(view, View.SCALE_X, 1f, 0.78f, 1.08f, 1f)
        val scaleY = ObjectAnimator.ofFloat(view, View.SCALE_Y, 1f, 0.78f, 1.08f, 1f)
        AnimatorSet().apply {
            playTogether(scaleX, scaleY)
            duration = 140L
            start()
        }
    }

    private fun dpToPx(context: Context, dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            context.resources.displayMetrics
        ).roundToInt()
    }
}
