package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.audio.SoundPlayerManager
import com.example.data.CursorPreferencesRepository
import com.example.overlay.FloatingCursorController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * [AccessibilityService] that intercepts global touch/click coordinates across the device.
 *
 * When a touch or click is detected, it delegates to [FloatingCursorController] which uses
 * [android.animation.ObjectAnimator] to smoothly slide the floating mouse cursor ImageView
 * to the (X, Y) coordinates of the touch and plays the user-selected click sound via
 * [android.media.MediaPlayer].
 */
class CursorAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "CursorAccessibilityService connected")
        CursorPreferencesRepository.init(applicationContext)
        SoundPlayerManager.preloadSelectedSound(applicationContext)
        _isServiceConnected.value = true

        // Automatically enable and show the overlay when the user turns on the AccessibilityService
        if (Settings.canDrawOverlays(applicationContext)) {
            CursorPreferencesRepository.setServiceToggleEnabled(true)
            FloatingCursorController.showCursorOverlay(applicationContext)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val settings = CursorPreferencesRepository.state.value
        if (!settings.isServiceToggleEnabled) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED,
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED,
            AccessibilityEvent.TYPE_VIEW_SELECTED,
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> {
                val now = SystemClock.uptimeMillis()
                // Avoid duplicate firing if MainActivity already dispatched raw touch coordinates
                if (now - lastDirectTouchTimestampMs < DIRECT_TOUCH_DEBOUNCE_MS) {
                    return
                }

                val coords = extractCoordinatesFromEvent(event)
                if (coords != null) {
                    val (targetX, targetY) = coords
                    FloatingCursorController.slideCursorToAndClick(
                        context = applicationContext,
                        targetX = targetX,
                        targetY = targetY,
                        playClickSoundOnArrival = true
                    )
                }
            }
            else -> Unit
        }
    }

    /**
     * Extracts accurate screen (X, Y) coordinates from the [AccessibilityEvent] source node bounds.
     */
    private fun extractCoordinatesFromEvent(event: AccessibilityEvent): Pair<Float, Float>? {
        val rect = Rect()
        return try {
            val node: AccessibilityNodeInfo? = event.source
            if (node != null) {
                node.getBoundsInScreen(rect)
                if (!rect.isEmpty && rect.width() > 0 && rect.height() > 0) {
                    return Pair(rect.exactCenterX(), rect.exactCenterY())
                }
            }
            null
        } catch (e: Exception) {
            Log.w(TAG, "Could not extract bounds from AccessibilityEvent: ${e.message}")
            null
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "CursorAccessibilityService interrupted")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        Log.d(TAG, "CursorAccessibilityService unbound")
        _isServiceConnected.value = false
        FloatingCursorController.hideCursorOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        _isServiceConnected.value = false
        FloatingCursorController.hideCursorOverlay()
        SoundPlayerManager.releaseAll()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "CursorAccessService"
        private const val DIRECT_TOUCH_DEBOUNCE_MS = 140L

        @Volatile
        private var lastDirectTouchTimestampMs: Long = 0L

        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()

        /**
         * Called when raw touch coordinates are intercepted directly (e.g., via
         * MainActivity.dispatchTouchEvent or interactive playground) for pixel-exact
         * cursor sliding and click audio playback.
         */
        fun notifyDirectTouchCoordinate(context: Context, rawX: Float, rawY: Float) {
            lastDirectTouchTimestampMs = SystemClock.uptimeMillis()
            FloatingCursorController.slideCursorToAndClick(
                context = context.applicationContext,
                targetX = rawX,
                targetY = rawY,
                playClickSoundOnArrival = true
            )
        }

        /**
         * Checks whether [CursorAccessibilityService] is enabled in Android system settings.
         */
        fun isAccessibilityServiceEnabled(context: Context): Boolean {
            if (_isServiceConnected.value) return true

            val expectedComponentName = ComponentName(context, CursorAccessibilityService::class.java)
            val enabledServicesSetting = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val colonSplitter = TextUtils.SimpleStringSplitter(':')
            colonSplitter.setString(enabledServicesSetting)
            while (colonSplitter.hasNext()) {
                val componentNameString = colonSplitter.next()
                val enabledComponent = ComponentName.unflattenFromString(componentNameString)
                if (enabledComponent != null && enabledComponent == expectedComponentName) {
                    return true
                }
            }
            return false
        }
    }
}
