package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundPlayerManager
import com.example.data.ClickSoundPreset
import com.example.data.CursorPreferencesRepository
import com.example.data.CursorSettingsState
import com.example.data.CursorStyle
import com.example.overlay.FloatingCursorController
import com.example.service.CursorAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PermissionUiState(
    val hasOverlayPermission: Boolean = false,
    val isAccessibilityServiceEnabled: Boolean = false,
    val showPermissionPromptBanner: Boolean = false,
    val statusMessage: String? = null
)

class CursorViewModel(application: Application) : AndroidViewModel(application) {

    // Properties MUST be declared before the init block so they are initialized before use
    val cursorSettings: StateFlow<CursorSettingsState> = CursorPreferencesRepository.state

    private val _permissionState = MutableStateFlow(PermissionUiState())
    val permissionState: StateFlow<PermissionUiState> = _permissionState.asStateFlow()

    init {
        val appContext = application.applicationContext
        CursorPreferencesRepository.init(appContext)
        refreshPermissions(appContext)
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                SoundPlayerManager.preloadSelectedSound(appContext)
            }
        }
    }

    fun refreshPermissions(context: Context = getApplication()) {
        val appContext = context.applicationContext
        val canDrawOverlays = runCatching { Settings.canDrawOverlays(appContext) }.getOrDefault(false)
        val accessibilityEnabled = runCatching {
            CursorAccessibilityService.isAccessibilityServiceEnabled(appContext)
        }.getOrDefault(false)

        _permissionState.update {
            it.copy(
                hasOverlayPermission = canDrawOverlays,
                isAccessibilityServiceEnabled = accessibilityEnabled
            )
        }

        if (cursorSettings.value.isServiceToggleEnabled && canDrawOverlays) {
            FloatingCursorController.showCursorOverlay(appContext)
        } else if (!cursorSettings.value.isServiceToggleEnabled) {
            FloatingCursorController.hideCursorOverlay()
        }
    }

    fun onToggleCursorService(enabled: Boolean, context: Context = getApplication()) {
        val appContext = context.applicationContext
        CursorPreferencesRepository.setServiceToggleEnabled(enabled)
        refreshPermissions(appContext)

        val canDraw = runCatching { Settings.canDrawOverlays(appContext) }.getOrDefault(false)
        val accEnabled = runCatching {
            CursorAccessibilityService.isAccessibilityServiceEnabled(appContext)
        }.getOrDefault(false)

        if (enabled) {
            if (canDraw) {
                FloatingCursorController.showCursorOverlay(appContext)
            }
            if (!canDraw || !accEnabled) {
                _permissionState.update {
                    it.copy(
                        showPermissionPromptBanner = true,
                        statusMessage = buildMissingPermissionMessage(canDraw, accEnabled)
                    )
                }
            } else {
                _permissionState.update {
                    it.copy(
                        showPermissionPromptBanner = false,
                        statusMessage = "Floating Cursor Service active across all apps"
                    )
                }
            }
            viewModelScope.launch(Dispatchers.IO) {
                SoundPlayerManager.playClickSound(appContext)
            }
        } else {
            FloatingCursorController.hideCursorOverlay()
            _permissionState.update {
                it.copy(
                    showPermissionPromptBanner = false,
                    statusMessage = "Floating Cursor Service paused"
                )
            }
        }
    }

    fun onCustomSoundUriSelected(context: Context, uri: Uri) {
        val appContext = context.applicationContext
        // Persist read permission so AccessibilityService can play the audio URI anytime
        runCatching {
            appContext.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        CursorPreferencesRepository.setCustomSoundUri(appContext, uri)
        _permissionState.update {
            it.copy(statusMessage = "Selected click sound: ${cursorSettings.value.selectedSoundDisplayName}")
        }
        viewModelScope.launch(Dispatchers.IO) {
            SoundPlayerManager.preloadSelectedSound(appContext)
            SoundPlayerManager.playClickSound(appContext)
        }
    }

    fun onSelectBuiltInPreset(preset: ClickSoundPreset, context: Context = getApplication()) {
        val appContext = context.applicationContext
        CursorPreferencesRepository.setBuiltInPreset(preset)
        viewModelScope.launch(Dispatchers.IO) {
            SoundPlayerManager.preloadSelectedSound(appContext)
            SoundPlayerManager.playClickSound(appContext)
        }
    }

    fun onSelectCursorStyle(style: CursorStyle, context: Context = getApplication()) {
        val appContext = context.applicationContext
        CursorPreferencesRepository.setCursorStyle(style)
        FloatingCursorController.refreshCursorAppearance(appContext)
    }

    fun onUpdateCursorSizeDp(sizeDp: Int, context: Context = getApplication()) {
        val appContext = context.applicationContext
        CursorPreferencesRepository.setCursorSizeDp(sizeDp)
        FloatingCursorController.refreshCursorAppearance(appContext)
    }

    fun onUpdateSlideDurationMs(durationMs: Long) {
        CursorPreferencesRepository.setSlideDurationMs(durationMs)
    }

    fun onUpdateSoundVolume(volume: Float) {
        CursorPreferencesRepository.setSoundVolume(volume)
    }

    fun testClickSound(context: Context = getApplication()) {
        val appContext = context.applicationContext
        viewModelScope.launch(Dispatchers.IO) {
            SoundPlayerManager.playClickSound(appContext)
        }
    }

    fun dismissPermissionBanner() {
        _permissionState.update { it.copy(showPermissionPromptBanner = false) }
    }

    private fun buildMissingPermissionMessage(canDraw: Boolean, accEnabled: Boolean): String {
        return when {
            !canDraw && !accEnabled ->
                "In-app cursor active! Grant 'Draw Over Other Apps' & 'Accessibility Service' below for system-wide overlay."
            !canDraw ->
                "Grant 'Draw Over Other Apps' permission to display the cursor outside this app."
            !accEnabled ->
                "Enable 'Touch Cursor Overlay Service' in Accessibility Settings to detect global touches across other apps."
            else -> "All permissions granted."
        }
    }
}
