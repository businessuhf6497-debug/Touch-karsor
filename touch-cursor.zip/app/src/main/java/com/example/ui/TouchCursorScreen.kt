package com.example.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.example.data.ClickSoundPreset
import com.example.data.CursorSettingsState
import com.example.data.CursorStyle
import com.example.overlay.FloatingCursorController
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyberIndigo
import com.example.ui.theme.DeepSlateSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElevatedSlateCard
import com.example.ui.theme.EmeraldActive
import com.example.ui.theme.GlassBorderSlate
import com.example.ui.theme.NeonCyanGlow
import com.example.ui.theme.ObsidianSlate
import kotlin.math.roundToInt

@Composable
fun TouchCursorScreen(
    settings: CursorSettingsState,
    permissionState: PermissionUiState,
    onSelectSoundClick: () -> Unit,
    onToggleCursorService: (Boolean) -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onRequestAccessibilityPermission: () -> Unit,
    onSelectPreset: (ClickSoundPreset) -> Unit,
    onSelectCursorStyle: (CursorStyle) -> Unit,
    onUpdateCursorSizeDp: (Int) -> Unit,
    onUpdateSlideDurationMs: (Long) -> Unit,
    onUpdateSoundVolume: (Float) -> Unit,
    onTestSoundClick: () -> Unit,
    onPlaygroundTap: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isSystemOverlayShowing = FloatingCursorController.isShowing()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(ObsidianSlate, DeepSlateSurface, ObsidianSlate)
                )
            )
    ) {
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            containerColor = Color.Transparent
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.TopCenter
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 640.dp)
                        .testTag("main_scroll_list"),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    // 1. Hero Header Card with generated visual art & live telemetry badge
                    item {
                        HeroBannerCard(
                            settings = settings,
                            permissionState = permissionState
                        )
                    }

                    // 2. Primary Action Controls: 'Start Cursor Service' Switch & 'Select Click Sound' Button
                    item {
                        PrimaryControlsCard(
                            settings = settings,
                            permissionState = permissionState,
                            onSelectSoundClick = onSelectSoundClick,
                            onToggleCursorService = onToggleCursorService,
                            onTestSoundClick = onTestSoundClick
                        )
                    }

                    // 3. System Permissions Status & Action Cards (SYSTEM_ALERT_WINDOW & AccessibilityService)
                    item {
                        PermissionsCard(
                            permissionState = permissionState,
                            onRequestOverlayPermission = onRequestOverlayPermission,
                            onRequestAccessibilityPermission = onRequestAccessibilityPermission
                        )
                    }

                    // 4. Interactive Touch & Slide Playground
                    item {
                        InteractiveTouchPlaygroundCard(
                            settings = settings,
                            onPlaygroundTap = onPlaygroundTap
                        )
                    }

                    // 5. Built-in Acoustic Click Presets & Custom Sound Info
                    item {
                        SoundPresetsCard(
                            settings = settings,
                            onSelectPreset = onSelectPreset,
                            onSelectSoundClick = onSelectSoundClick,
                            onTestSoundClick = onTestSoundClick
                        )
                    }

                    // 6. Cursor Appearance & ObjectAnimator Slide Tuning
                    item {
                        CursorTuningCard(
                            settings = settings,
                            onSelectCursorStyle = onSelectCursorStyle,
                            onUpdateCursorSizeDp = onUpdateCursorSizeDp,
                            onUpdateSlideDurationMs = onUpdateSlideDurationMs,
                            onUpdateSoundVolume = onUpdateSoundVolume
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }

        // In-Window Floating Cursor ImageView fallback powered by ObjectAnimator
        // Renders inside the app window whenever the service toggle is ON (or user taps the playground)
        // and the system-wide TYPE_APPLICATION_OVERLAY window isn't already attached, ensuring zero
        // duplicate cursors while allowing immediate testing of ObjectAnimator + MediaPlayer!
        if (!isSystemOverlayShowing) {
            InWindowObjectAnimatorCursorOverlay(
                settings = settings,
                visible = settings.isServiceToggleEnabled || settings.totalClicksIntercepted > 0
            )
        }
    }
}

@Composable
private fun HeroBannerCard(
    settings: CursorSettingsState,
    permissionState: PermissionUiState
) {
    val allPermissionsReady =
        permissionState.hasOverlayPermission && permissionState.isAccessibilityServiceEnabled

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(NeonCyanGlow.copy(alpha = 0.55f), CyberIndigo.copy(alpha = 0.55f))
                ),
                shape = RoundedCornerShape(24.dp)
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = ElevatedSlateCard)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_cursor_1794272725739),
                contentDescription = stringResource(R.string.app_name),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(188.dp)
            )

            // Gradient scrim for crisp typography legibility
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(188.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                ObsidianSlate.copy(alpha = 0.35f),
                                ObsidianSlate.copy(alpha = 0.78f),
                                ObsidianSlate.copy(alpha = 0.96f)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (settings.isServiceToggleEnabled) {
                            EmeraldActive.copy(alpha = 0.22f)
                        } else {
                            ObsidianSlate.copy(alpha = 0.72f)
                        },
                        shape = CircleShape,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (settings.isServiceToggleEnabled) EmeraldActive else GlassBorderSlate
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (settings.isServiceToggleEnabled) EmeraldActive else AmberWarning
                                    )
                            )
                            Text(
                                text = if (settings.isServiceToggleEnabled && allPermissionsReady) {
                                    "GLOBAL OVERLAY ACTIVE"
                                } else if (settings.isServiceToggleEnabled) {
                                    "CURSOR ACTIVE (IN-APP)"
                                } else {
                                    "STANDBY"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White
                            )
                        }
                    }

                    // Live X, Y Coordinates Telemetry Pill
                    Surface(
                        color = ObsidianSlate.copy(alpha = 0.78f),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            NeonCyanGlow.copy(alpha = 0.45f)
                        )
                    ) {
                        Text(
                            text = "X:${settings.lastTouchX.roundToInt()}  Y:${settings.lastTouchY.roundToInt()}  •  #${settings.totalClicksIntercepted}",
                            style = MaterialTheme.typography.labelMedium,
                            color = NeonCyanGlow,
                            modifier = Modifier
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                                .testTag("telemetry_coordinates_text")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(48.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        color = ObsidianSlate.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyanGlow)
                    ) {
                        Image(
                            painter = painterResource(id = settings.cursorStyle.drawableRes),
                            contentDescription = "Active Cursor Preview",
                            modifier = Modifier
                                .padding(8.dp)
                                .size(30.dp)
                        )
                    }

                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White
                        )
                        Text(
                            text = stringResource(R.string.hero_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = NeonCyanGlow
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PrimaryControlsCard(
    settings: CursorSettingsState,
    permissionState: PermissionUiState,
    onSelectSoundClick: () -> Unit,
    onToggleCursorService: (Boolean) -> Unit,
    onTestSoundClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GlassBorderSlate, RoundedCornerShape(22.dp)),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ElevatedSlateCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. 'Start Cursor Service' Switch / Toggle Button Row
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .clickable { onToggleCursorService(!settings.isServiceToggleEnabled) }
                    .testTag("start_cursor_service_toggle"),
                color = if (settings.isServiceToggleEnabled) {
                    ElectricCyan.copy(alpha = 0.14f)
                } else {
                    ObsidianSlate.copy(alpha = 0.65f)
                },
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(
                    width = 1.5.dp,
                    color = if (settings.isServiceToggleEnabled) NeonCyanGlow else GlassBorderSlate
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (settings.isServiceToggleEnabled) {
                                        NeonCyanGlow.copy(alpha = 0.2f)
                                    } else {
                                        GlassBorderSlate.copy(alpha = 0.35f)
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Mouse,
                                contentDescription = stringResource(R.string.start_cursor_service),
                                tint = if (settings.isServiceToggleEnabled) NeonCyanGlow else Color.White
                            )
                        }

                        Column {
                            Text(
                                text = stringResource(R.string.start_cursor_service),
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (settings.isServiceToggleEnabled) {
                                    "Floating cursor & click audio enabled"
                                } else {
                                    "Toggle on to display floating mouse cursor"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Switch(
                        checked = settings.isServiceToggleEnabled,
                        onCheckedChange = onToggleCursorService,
                        modifier = Modifier.testTag("start_cursor_service_switch"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ObsidianSlate,
                            checkedTrackColor = NeonCyanGlow,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = GlassBorderSlate
                        )
                    )
                }
            }

            // Active Sound File Info Banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(ObsidianSlate.copy(alpha = 0.55f))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Filled.MusicNote,
                        contentDescription = "Selected Sound Effect",
                        tint = NeonCyanGlow,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "Active Click Sound URI",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = settings.selectedSoundDisplayName,
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("selected_sound_name_text")
                        )
                    }
                }

                OutlinedButton(
                    onClick = onTestSoundClick,
                    modifier = Modifier.testTag("test_click_sound_button"),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyanGlow.copy(alpha = 0.6f))
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = stringResource(R.string.test_click_sound),
                        tint = NeonCyanGlow,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Test",
                        style = MaterialTheme.typography.labelLarge,
                        color = NeonCyanGlow
                    )
                }
            }

            // 2. 'Select Click Sound' Button (Opens file picker to choose an audio file like .mp3)
            Button(
                onClick = onSelectSoundClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("select_click_sound_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCyanGlow,
                    contentColor = ObsidianSlate
                )
            ) {
                Icon(
                    imageVector = Icons.Filled.AudioFile,
                    contentDescription = stringResource(R.string.select_click_sound),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = stringResource(R.string.select_click_sound),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            // Status / Permission guidance banner when applicable
            AnimatedVisibility(
                visible = !permissionState.statusMessage.isNullOrBlank(),
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberIndigo.copy(alpha = 0.16f))
                        .border(1.dp, CyberIndigo.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Info,
                        contentDescription = "Status Info",
                        tint = NeonCyanGlow,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = permissionState.statusMessage.orEmpty(),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionsCard(
    permissionState: PermissionUiState,
    onRequestOverlayPermission: () -> Unit,
    onRequestAccessibilityPermission: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GlassBorderSlate, RoundedCornerShape(22.dp)),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ElevatedSlateCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Layers,
                    contentDescription = "System Permissions",
                    tint = NeonCyanGlow
                )
                Text(
                    text = "Overlay & Accessibility Permissions",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
            }

            // Permission 1: SYSTEM_ALERT_WINDOW (Draw over other apps)
            PermissionItemRow(
                icon = Icons.Filled.Layers,
                title = stringResource(R.string.permission_overlay_title),
                description = stringResource(R.string.permission_overlay_desc),
                isGranted = permissionState.hasOverlayPermission,
                buttonTestTag = "request_overlay_permission_button",
                onActionClick = onRequestOverlayPermission
            )

            // Permission 2: AccessibilityService (Global Touch & Click coordinates)
            PermissionItemRow(
                icon = Icons.Filled.AccessibilityNew,
                title = stringResource(R.string.permission_accessibility_title),
                description = stringResource(R.string.permission_accessibility_desc),
                isGranted = permissionState.isAccessibilityServiceEnabled,
                buttonTestTag = "request_accessibility_permission_button",
                onActionClick = onRequestAccessibilityPermission
            )
        }
    }
}

@Composable
private fun PermissionItemRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    isGranted: Boolean,
    buttonTestTag: String,
    onActionClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ObsidianSlate.copy(alpha = 0.55f),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (isGranted) EmeraldActive.copy(alpha = 0.5f) else GlassBorderSlate
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (isGranted) EmeraldActive.copy(alpha = 0.18f)
                            else AmberWarning.copy(alpha = 0.18f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isGranted) Icons.Filled.CheckCircle else icon,
                        contentDescription = title,
                        tint = if (isGranted) EmeraldActive else AmberWarning
                    )
                }

                Column(modifier = Modifier.padding(end = 8.dp)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (isGranted) {
                Surface(
                    color = EmeraldActive.copy(alpha = 0.18f),
                    shape = CircleShape,
                    modifier = Modifier
                        .clickable(onClick = onActionClick)
                        .testTag(buttonTestTag)
                ) {
                    Text(
                        text = stringResource(R.string.permission_granted),
                        style = MaterialTheme.typography.labelLarge,
                        color = EmeraldActive,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            } else {
                Button(
                    onClick = onActionClick,
                    modifier = Modifier.testTag(buttonTestTag),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberIndigo,
                        contentColor = Color.White
                    )
                ) {
                    Text(
                        text = stringResource(R.string.grant_permission),
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Outlined.OpenInNew,
                        contentDescription = stringResource(R.string.grant_permission),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun InteractiveTouchPlaygroundCard(
    settings: CursorSettingsState,
    onPlaygroundTap: (Float, Float) -> Unit
) {
    var padOriginInRoot by remember { mutableStateOf(Offset.Zero) }
    var lastLocalTap by remember { mutableStateOf<Offset?>(null) }
    val rippleProgress = remember { Animatable(0f) }

    LaunchedEffect(settings.totalClicksIntercepted) {
        if (settings.totalClicksIntercepted > 0) {
            rippleProgress.snapTo(0f)
            rippleProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 480, easing = FastOutSlowInEasing)
            )
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, NeonCyanGlow.copy(alpha = 0.45f), RoundedCornerShape(22.dp)),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ElevatedSlateCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.TouchApp,
                    contentDescription = stringResource(R.string.interactive_playground_title),
                    tint = NeonCyanGlow
                )
                Column {
                    Text(
                        text = stringResource(R.string.interactive_playground_title),
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White
                    )
                    Text(
                        text = stringResource(R.string.interactive_playground_subtitle),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(ObsidianSlate)
                    .border(1.dp, GlassBorderSlate, RoundedCornerShape(16.dp))
                    .onGloballyPositioned { coords ->
                        padOriginInRoot = coords.positionInRoot()
                    }
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = { localOffset ->
                                lastLocalTap = localOffset
                                val globalX = padOriginInRoot.x + localOffset.x
                                val globalY = padOriginInRoot.y + localOffset.y
                                onPlaygroundTap(globalX, globalY)
                            }
                        )
                    }
                    .testTag("interactive_touch_playground")
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val step = 28.dp.toPx()
                    var x = step
                    while (x < size.width) {
                        drawLine(
                            color = GlassBorderSlate.copy(alpha = 0.25f),
                            start = Offset(x, 0f),
                            end = Offset(x, size.height),
                            strokeWidth = 1f
                        )
                        x += step
                    }
                    var y = step
                    while (y < size.height) {
                        drawLine(
                            color = GlassBorderSlate.copy(alpha = 0.25f),
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 1f
                        )
                        y += step
                    }

                    // Draw acoustic click ripple wave at the tapped location
                    lastLocalTap?.let { tap ->
                        val p = rippleProgress.value
                        if (p < 1f) {
                            val maxRadius = 68.dp.toPx()
                            drawCircle(
                                color = NeonCyanGlow.copy(alpha = (1f - p) * 0.75f),
                                radius = maxRadius * p,
                                center = tap,
                                style = Stroke(width = 3.dp.toPx())
                            )
                            drawCircle(
                                color = CyberIndigo.copy(alpha = (1f - p) * 0.55f),
                                radius = maxRadius * (p * 0.65f),
                                center = tap,
                                style = Stroke(width = 2.dp.toPx())
                            )
                        }
                        drawCircle(
                            color = NeonCyanGlow,
                            radius = 4.dp.toPx(),
                            center = tap
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "TAP ANYWHERE TO SLIDE CURSOR & CLICK",
                        style = MaterialTheme.typography.labelLarge,
                        color = NeonCyanGlow.copy(alpha = 0.85f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ObjectAnimator (${settings.slideDurationMs}ms) + MediaPlayer Audio",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SoundPresetsCard(
    settings: CursorSettingsState,
    onSelectPreset: (ClickSoundPreset) -> Unit,
    onSelectSoundClick: () -> Unit,
    onTestSoundClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GlassBorderSlate, RoundedCornerShape(22.dp)),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ElevatedSlateCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.GraphicEq,
                    contentDescription = stringResource(R.string.built_in_presets_label),
                    tint = NeonCyanGlow
                )
                Text(
                    text = stringResource(R.string.built_in_presets_label),
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
            }

            Text(
                text = "Choose a synthesized acoustic click or pick any custom .mp3/.wav file from your device:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    ClickSoundPreset.MECHANICAL_CLICK,
                    ClickSoundPreset.CYBER_PULSE,
                    ClickSoundPreset.SOFT_POP
                ).forEach { preset ->
                    val isSelected = settings.selectedPreset == preset
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectPreset(preset) },
                        label = {
                            Text(
                                text = preset.label,
                                style = MaterialTheme.typography.labelLarge
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonCyanGlow.copy(alpha = 0.22f),
                            selectedLabelColor = NeonCyanGlow,
                            containerColor = ObsidianSlate.copy(alpha = 0.6f),
                            labelColor = Color.White
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = GlassBorderSlate,
                            selectedBorderColor = NeonCyanGlow
                        )
                    )
                }

                val isCustomSelected = settings.selectedPreset == ClickSoundPreset.CUSTOM_FILE
                FilterChip(
                    selected = isCustomSelected,
                    onClick = onSelectSoundClick,
                    label = {
                        Text(
                            text = if (isCustomSelected) {
                                "Custom: ${settings.selectedSoundDisplayName}"
                            } else {
                                "Browse Custom .MP3..."
                            },
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyberIndigo.copy(alpha = 0.28f),
                        selectedLabelColor = Color.White,
                        containerColor = ObsidianSlate.copy(alpha = 0.6f),
                        labelColor = NeonCyanGlow
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isCustomSelected,
                        borderColor = NeonCyanGlow.copy(alpha = 0.5f),
                        selectedBorderColor = CyberIndigo
                    )
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CursorTuningCard(
    settings: CursorSettingsState,
    onSelectCursorStyle: (CursorStyle) -> Unit,
    onUpdateCursorSizeDp: (Int) -> Unit,
    onUpdateSlideDurationMs: (Long) -> Unit,
    onUpdateSoundVolume: (Float) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GlassBorderSlate, RoundedCornerShape(22.dp)),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ElevatedSlateCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Tune,
                    contentDescription = stringResource(R.string.cursor_customization_title),
                    tint = NeonCyanGlow
                )
                Text(
                    text = stringResource(R.string.cursor_customization_title),
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
            }

            // Cursor Style Picker
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CursorStyle.entries.forEach { style ->
                    val selected = settings.cursorStyle == style
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onSelectCursorStyle(style) },
                        color = if (selected) NeonCyanGlow.copy(alpha = 0.18f) else ObsidianSlate.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) NeonCyanGlow else GlassBorderSlate
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Image(
                                painter = painterResource(id = style.drawableRes),
                                contentDescription = style.label,
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = style.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) NeonCyanGlow else Color.White
                            )
                        }
                    }
                }
            }

            // Slide Animation Duration Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Speed,
                            contentDescription = null,
                            tint = NeonCyanGlow,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = stringResource(R.string.slide_duration_label),
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White
                        )
                    }
                    Text(
                        text = "${settings.slideDurationMs} ms",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonCyanGlow
                    )
                }
                Slider(
                    value = settings.slideDurationMs.toFloat(),
                    onValueChange = { onUpdateSlideDurationMs(it.roundToInt().toLong()) },
                    valueRange = 50f..600f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyanGlow,
                        activeTrackColor = NeonCyanGlow
                    ),
                    modifier = Modifier.testTag("slide_duration_slider")
                )
            }

            // Cursor Size Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Mouse,
                            contentDescription = null,
                            tint = NeonCyanGlow,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = stringResource(R.string.cursor_size_label),
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White
                        )
                    }
                    Text(
                        text = "${settings.cursorSizeDp} dp",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonCyanGlow
                    )
                }
                Slider(
                    value = settings.cursorSizeDp.toFloat(),
                    onValueChange = { onUpdateCursorSizeDp(it.roundToInt()) },
                    valueRange = 24f..64f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyanGlow,
                        activeTrackColor = NeonCyanGlow
                    ),
                    modifier = Modifier.testTag("cursor_size_slider")
                )
            }

            // Click Sound Volume Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.VolumeUp,
                            contentDescription = null,
                            tint = NeonCyanGlow,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = stringResource(R.string.sound_volume_label),
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White
                        )
                    }
                    Text(
                        text = "${(settings.soundVolume * 100).roundToInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonCyanGlow
                    )
                }
                Slider(
                    value = settings.soundVolume,
                    onValueChange = onUpdateSoundVolume,
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyanGlow,
                        activeTrackColor = NeonCyanGlow
                    ),
                    modifier = Modifier.testTag("sound_volume_slider")
                )
            }
        }
    }
}

/**
 * Renders a real Android [ImageView] mouse cursor layer inside the activity window
 * and animates its position with [ObjectAnimator] (`TRANSLATION_X`, `TRANSLATION_Y`)
 * whenever the system-wide `TYPE_APPLICATION_OVERLAY` window is not yet attached.
 */
@Composable
private fun InWindowObjectAnimatorCursorOverlay(
    settings: CursorSettingsState,
    visible: Boolean
) {
    if (!visible) return

    val density = LocalDensity.current
    val cursorSizePx = with(density) { settings.cursorSizeDp.dp.roundToPx() }

    AndroidView(
        modifier = Modifier
            .fillMaxSize()
            .testTag("in_window_cursor_overlay"),
        factory = { context ->
            FrameLayout(context).apply {
                isClickable = false
                isFocusable = false
                val cursorView = ImageView(context).apply {
                    id = android.R.id.icon
                    setImageResource(settings.cursorStyle.drawableRes)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    translationX = settings.lastTouchX
                    translationY = settings.lastTouchY
                }
                addView(cursorView, FrameLayout.LayoutParams(cursorSizePx, cursorSizePx))
            }
        },
        update = { container ->
            val cursorView = container.findViewById<ImageView>(android.R.id.icon) ?: return@AndroidView
            cursorView.setImageResource(settings.cursorStyle.drawableRes)
            val lp = cursorView.layoutParams
            if (lp.width != cursorSizePx || lp.height != cursorSizePx) {
                lp.width = cursorSizePx
                lp.height = cursorSizePx
                cursorView.layoutParams = lp
            }

            val targetX = settings.lastTouchX
            val targetY = settings.lastTouchY
            if (cursorView.translationX != targetX || cursorView.translationY != targetY) {
                val animX = ObjectAnimator.ofFloat(
                    cursorView,
                    View.TRANSLATION_X,
                    cursorView.translationX,
                    targetX
                )
                val animY = ObjectAnimator.ofFloat(
                    cursorView,
                    View.TRANSLATION_Y,
                    cursorView.translationY,
                    targetY
                )
                AnimatorSet().apply {
                    playTogether(animX, animY)
                    duration = settings.slideDurationMs
                    interpolator = DecelerateInterpolator(1.6f)
                    addListener(object : AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: Animator) {
                            val pulseX = ObjectAnimator.ofFloat(cursorView, View.SCALE_X, 1f, 0.8f, 1.08f, 1f)
                            val pulseY = ObjectAnimator.ofFloat(cursorView, View.SCALE_Y, 1f, 0.8f, 1.08f, 1f)
                            AnimatorSet().apply {
                                playTogether(pulseX, pulseY)
                                duration = 130L
                                start()
                            }
                        }
                    })
                    start()
                }
            }
        }
    )
}
