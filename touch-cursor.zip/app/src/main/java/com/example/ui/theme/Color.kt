package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianSlate = Color(0xFF0B1120)
val DeepSlateSurface = Color(0xFF111827)
val ElevatedSlateCard = Color(0xFF1E293B)
val GlassBorderSlate = Color(0xFF334155)

val ElectricCyan = Color(0xFF06B6D4)
val NeonCyanGlow = Color(0xFF22D3EE)
val CyberIndigo = Color(0xFF6366F1)
val SoftIndigoAccent = Color(0xFF818CF8)

val EmeraldActive = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RoseAlert = Color(0xFFF43F5E)

val TextPrimaryLight = Color(0xFFF8FAFC)
val TextSecondaryMuted = Color(0xFF94A3B8)

val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightPrimaryCyan = Color(0xFF0891B2)
val LightSecondaryIndigo = Color(0xFF4F46E5)
val TextPrimaryDark = Color(0xFF0F172A)
val TextSecondaryDark = Color(0xFF475569)
