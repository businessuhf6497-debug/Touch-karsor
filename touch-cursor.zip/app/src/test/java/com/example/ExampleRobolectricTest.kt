package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.audio.SoundPlayerManager
import com.example.data.ClickSoundPreset
import com.example.data.CursorPreferencesRepository
import com.example.overlay.FloatingCursorController
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name and verify cursor preferences and rapid click audio`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Touch Cursor", appName)

        CursorPreferencesRepository.init(context)
        CursorPreferencesRepository.setServiceToggleEnabled(true)
        assertTrue(CursorPreferencesRepository.state.value.isServiceToggleEnabled)

        CursorPreferencesRepository.setBuiltInPreset(ClickSoundPreset.CYBER_PULSE)
        assertEquals(ClickSoundPreset.CYBER_PULSE, CursorPreferencesRepository.state.value.selectedPreset)

        // Rapid consecutive click stress test on SoundPlayerManager & FloatingCursorController
        repeat(10) { idx ->
            FloatingCursorController.slideCursorToAndClick(
                context = context,
                targetX = 120f + idx * 15f,
                targetY = 240f + idx * 20f,
                playClickSoundOnArrival = true
            )
            SoundPlayerManager.playClickSound(context)
        }

        assertEquals(120f + 9 * 15f, CursorPreferencesRepository.state.value.lastTouchX, 0.01f)
        assertEquals(240f + 9 * 20f, CursorPreferencesRepository.state.value.lastTouchY, 0.01f)
        SoundPlayerManager.releaseAll()
    }
}
