package com.example

import com.example.data.ClickSoundPreset
import com.example.data.CursorPreferencesRepository
import com.example.data.CursorStyle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun cursorPreferences_updatesStateAndCoordinatesCorrectly() {
        CursorPreferencesRepository.setServiceToggleEnabled(true)
        assertTrue(CursorPreferencesRepository.state.value.isServiceToggleEnabled)

        CursorPreferencesRepository.setBuiltInPreset(ClickSoundPreset.CYBER_PULSE)
        assertEquals(ClickSoundPreset.CYBER_PULSE, CursorPreferencesRepository.state.value.selectedPreset)

        CursorPreferencesRepository.setCursorStyle(CursorStyle.NEON_INDIGO)
        assertEquals(CursorStyle.NEON_INDIGO, CursorPreferencesRepository.state.value.cursorStyle)

        CursorPreferencesRepository.setCursorSizeDp(48)
        assertEquals(48, CursorPreferencesRepository.state.value.cursorSizeDp)

        CursorPreferencesRepository.setSlideDurationMs(180L)
        assertEquals(180L, CursorPreferencesRepository.state.value.slideDurationMs)

        CursorPreferencesRepository.recordTouchEvent(315.5f, 642.0f)
        assertEquals(315.5f, CursorPreferencesRepository.state.value.lastTouchX, 0.01f)
        assertEquals(642.0f, CursorPreferencesRepository.state.value.lastTouchY, 0.01f)
    }
}
